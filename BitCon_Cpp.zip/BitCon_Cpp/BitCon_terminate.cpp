//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: BitCon_terminate.cpp
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 08-May-2019 16:25:51
//

// Include Files
#include "rt_nonfinite.h"
#include "BitCon.h"
#include "BitCon_terminate.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void BitCon_terminate()
{
  // (no terminate code required)
}

//
// File trailer for BitCon_terminate.cpp
//
// [EOF]
//
