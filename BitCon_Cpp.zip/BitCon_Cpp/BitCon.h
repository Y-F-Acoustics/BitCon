//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: BitCon.h
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 08-May-2019 16:25:51
//
#ifndef BITCON_H
#define BITCON_H

// Include Files
#include <cmath>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "BitCon_types.h"

// Function Declarations
extern void BitCon(const emxArray_real_T *x, double Bits, emxArray_real_T *y);

#endif

//
// File trailer for BitCon.h
//
// [EOF]
//
