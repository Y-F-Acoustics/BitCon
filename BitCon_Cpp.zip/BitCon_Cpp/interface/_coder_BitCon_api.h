/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: _coder_BitCon_api.h
 *
 * MATLAB Coder version            : 3.3
 * C/C++ source code generated on  : 08-May-2019 16:25:51
 */

#ifndef _CODER_BITCON_API_H
#define _CODER_BITCON_API_H

/* Include Files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include <stddef.h>
#include <stdlib.h>
#include "_coder_BitCon_api.h"

/* Type Definitions */
#ifndef struct_emxArray_real_T
#define struct_emxArray_real_T

struct emxArray_real_T
{
  real_T *data;
  int32_T *size;
  int32_T allocatedSize;
  int32_T numDimensions;
  boolean_T canFreeData;
};

#endif                                 /*struct_emxArray_real_T*/

#ifndef typedef_emxArray_real_T
#define typedef_emxArray_real_T

typedef struct emxArray_real_T emxArray_real_T;

#endif                                 /*typedef_emxArray_real_T*/

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

/* Function Declarations */
extern void BitCon(emxArray_real_T *x, real_T Bits, emxArray_real_T *y);
extern void BitCon_api(const mxArray * const prhs[2], const mxArray *plhs[1]);
extern void BitCon_atexit(void);
extern void BitCon_initialize(void);
extern void BitCon_terminate(void);
extern void BitCon_xil_terminate(void);

#endif

/*
 * File trailer for _coder_BitCon_api.h
 *
 * [EOF]
 */
