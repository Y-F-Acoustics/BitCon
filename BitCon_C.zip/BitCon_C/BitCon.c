/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: BitCon.c
 *
 * MATLAB Coder version            : 3.3
 * C/C++ source code generated on  : 08-May-2019 16:22:15
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "BitCon.h"
#include "BitCon_emxutil.h"
#include "abs.h"

/* Function Declarations */
static double rt_powd_snf(double u0, double u1);

/* Function Definitions */

/*
 * Arguments    : double u0
 *                double u1
 * Return Type  : double
 */
static double rt_powd_snf(double u0, double u1)
{
  double y;
  double d0;
  double d1;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = rtNaN;
  } else {
    d0 = fabs(u0);
    d1 = fabs(u1);
    if (rtIsInf(u1)) {
      if (d0 == 1.0) {
        y = 1.0;
      } else if (d0 > 1.0) {
        if (u1 > 0.0) {
          y = rtInf;
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = rtInf;
      }
    } else if (d1 == 0.0) {
      y = 1.0;
    } else if (d1 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > floor(u1))) {
      y = rtNaN;
    } else {
      y = pow(u0, u1);
    }
  }

  return y;
}

/*
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * �ʎq���r�b�g���ϊ��֐�
 *
 *    �f�[�^x��Bits�Ɏ������ʎq���r�b�g���ɕϊ�
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * Arguments    : const emxArray_real_T *x
 *                double Bits
 *                emxArray_real_T *y
 * Return Type  : void
 */
void BitCon(const emxArray_real_T *x, double Bits, emxArray_real_T *y)
{
  int n;
  int nx;
  emxArray_real_T *maxval;
  emxArray_real_T *varargin_1;
  emxArray_boolean_T *b_x;
  int ix;
  int ixstart;
  int ixstop;
  double c;
  boolean_T exitg1;
  boolean_T b_y;

  /* �z��y��x���R�s�[ */
  n = y->size[0] * y->size[1];
  y->size[0] = x->size[0];
  y->size[1] = x->size[1];
  emxEnsureCapacity((emxArray__common *)y, n, sizeof(double));
  nx = x->size[0] * x->size[1];
  for (n = 0; n < nx; n++) {
    y->data[n] = x->data[n];
  }

  emxInit_real_T(&maxval, 2);
  emxInit_real_T(&varargin_1, 2);

  /* [-1, 1]�ɐ��K�� */
  b_abs(x, varargin_1);
  n = maxval->size[0] * maxval->size[1];
  maxval->size[0] = 1;
  maxval->size[1] = varargin_1->size[1];
  emxEnsureCapacity((emxArray__common *)maxval, n, sizeof(double));
  n = varargin_1->size[0];
  for (nx = 0; nx + 1 <= varargin_1->size[1]; nx++) {
    ix = nx * n;
    ixstart = nx * n + 1;
    ixstop = ix + n;
    c = varargin_1->data[ix];
    if (n > 1) {
      if (rtIsNaN(varargin_1->data[ix])) {
        ix = ixstart + 1;
        exitg1 = false;
        while ((!exitg1) && (ix <= ixstop)) {
          ixstart = ix;
          if (!rtIsNaN(varargin_1->data[ix - 1])) {
            c = varargin_1->data[ix - 1];
            exitg1 = true;
          } else {
            ix++;
          }
        }
      }

      if (ixstart < ixstop) {
        while (ixstart + 1 <= ixstop) {
          if (varargin_1->data[ixstart] > c) {
            c = varargin_1->data[ixstart];
          }

          ixstart++;
        }
      }
    }

    maxval->data[nx] = c;
  }

  emxInit_boolean_T(&b_x, 2);
  n = b_x->size[0] * b_x->size[1];
  b_x->size[0] = 1;
  b_x->size[1] = maxval->size[1];
  emxEnsureCapacity((emxArray__common *)b_x, n, sizeof(boolean_T));
  nx = maxval->size[0] * maxval->size[1];
  for (n = 0; n < nx; n++) {
    b_x->data[n] = (maxval->data[n] > 1.0);
  }

  b_y = !(b_x->size[1] == 0);
  if (b_y) {
    n = 1;
    exitg1 = false;
    while ((!exitg1) && (n <= b_x->size[1])) {
      if (!b_x->data[n - 1]) {
        b_y = false;
        exitg1 = true;
      } else {
        n++;
      }
    }
  }

  emxFree_boolean_T(&b_x);
  if (b_y) {
    b_abs(x, varargin_1);
    n = maxval->size[0] * maxval->size[1];
    maxval->size[0] = 1;
    maxval->size[1] = varargin_1->size[1];
    emxEnsureCapacity((emxArray__common *)maxval, n, sizeof(double));
    n = varargin_1->size[0];
    for (nx = 0; nx + 1 <= varargin_1->size[1]; nx++) {
      ix = nx * n;
      ixstart = nx * n + 1;
      ixstop = ix + n;
      c = varargin_1->data[ix];
      if (n > 1) {
        if (rtIsNaN(varargin_1->data[ix])) {
          ix = ixstart + 1;
          exitg1 = false;
          while ((!exitg1) && (ix <= ixstop)) {
            ixstart = ix;
            if (!rtIsNaN(varargin_1->data[ix - 1])) {
              c = varargin_1->data[ix - 1];
              exitg1 = true;
            } else {
              ix++;
            }
          }
        }

        if (ixstart < ixstop) {
          while (ixstart + 1 <= ixstop) {
            if (varargin_1->data[ixstart] > c) {
              c = varargin_1->data[ixstart];
            }

            ixstart++;
          }
        }
      }

      maxval->data[nx] = c;
    }

    n = y->size[0] * y->size[1];
    y->size[0] = x->size[0];
    y->size[1] = x->size[1];
    emxEnsureCapacity((emxArray__common *)y, n, sizeof(double));
    nx = x->size[0] * x->size[1];
    for (n = 0; n < nx; n++) {
      y->data[n] = x->data[n] / maxval->data[n];
    }
  }

  emxFree_real_T(&varargin_1);
  emxFree_real_T(&maxval);

  /* �����l�ɕϊ� */
  c = rt_powd_snf(2.0, Bits);
  n = y->size[0] * y->size[1];
  emxEnsureCapacity((emxArray__common *)y, n, sizeof(double));
  nx = y->size[0];
  n = y->size[1];
  nx *= n;
  for (n = 0; n < nx; n++) {
    y->data[n] = (y->data[n] + 1.0) / 2.0 * (c - 1.0) - 0.5;
  }

  /* �o�C�A�X�𗎂Ƃ� */
  nx = y->size[0] * y->size[1];
  for (n = 0; n + 1 <= nx; n++) {
    y->data[n] = floor(y->data[n]);
  }

  c = rt_powd_snf(2.0, Bits - 1.0);
  n = y->size[0] * y->size[1];
  emxEnsureCapacity((emxArray__common *)y, n, sizeof(double));
  nx = y->size[0];
  n = y->size[1];
  nx *= n;
  for (n = 0; n < nx; n++) {
    y->data[n] -= c - 1.0;
  }

  /* �Œ菬���l�� */
  c = rt_powd_snf(2.0, Bits - 1.0);
  n = y->size[0] * y->size[1];
  emxEnsureCapacity((emxArray__common *)y, n, sizeof(double));
  nx = y->size[0];
  n = y->size[1];
  nx *= n;
  for (n = 0; n < nx; n++) {
    y->data[n] /= c;
  }
}

/*
 * File trailer for BitCon.c
 *
 * [EOF]
 */
